import { initializeApp } from 'firebase/app';
import { 
  getFirestore, collection, doc, setDoc, getDocs, deleteDoc, 
  query, onSnapshot, Timestamp 
} from 'firebase/firestore';

// ==================== Firebase Config (Replace with your own) ====================
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase only if config is valid
let app: any = null;
let firestore: any = null;
let isFirebaseEnabled = false;

try {
  if (firebaseConfig.apiKey !== "YOUR_API_KEY") {
    app = initializeApp(firebaseConfig);
    firestore = getFirestore(app);
    isFirebaseEnabled = true;
    console.log('%c[HybridDB] Firebase initialized successfully', 'color: #22c55e');
  }
} catch (e) {
  console.warn('[HybridDB] Firebase disabled - using IndexedDB only');
}

// ==================== IndexedDB (Primary) ====================
const DB_NAME = 'MGroupCoolERP';
const DB_VERSION = 2;

class IndexedDBService {
  private db: IDBDatabase | null = null;

  async init() {
    return new Promise<void>((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        const stores = ['customers', 'maintenance', 'installation', 'contracts', 'invoices', 'payments', 'employees'];
        stores.forEach(store => {
          if (!db.objectStoreNames.contains(store)) {
            db.createObjectStore(store, { keyPath: 'id' });
          }
        });
      };
    });
  }

  async getAll<T>(store: string): Promise<T[]> {
    if (!this.db) return [];
    return new Promise((resolve) => {
      const tx = this.db!.transaction(store, 'readonly');
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  }

  async put(store: string, item: any) {
    if (!this.db) return;
    return new Promise<void>((resolve) => {
      const tx = this.db!.transaction(store, 'readwrite');
      tx.objectStore(store).put(item);
      tx.oncomplete = () => resolve();
    });
  }

  async delete(store: string, id: string) {
    if (!this.db) return;
    return new Promise<void>((resolve) => {
      const tx = this.db!.transaction(store, 'readwrite');
      tx.objectStore(store).delete(id);
      tx.oncomplete = () => resolve();
    });
  }
}

// ==================== Hybrid Database ====================
class HybridDB {
  private idb = new IndexedDBService();
  private isOnline = navigator.onLine;
  private syncQueue: any[] = [];

  async init() {
    await this.idb.init();
    
    // Listen for online/offline
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());
    
    if (this.isOnline && isFirebaseEnabled) {
      this.startSync();
    }
  }

  private handleOnline() {
    this.isOnline = true;
    console.log('%c[HybridDB] Back online - starting sync', 'color: #22c55e');
    if (isFirebaseEnabled) this.startSync();
  }

  private handleOffline() {
    this.isOnline = false;
    console.log('%c[HybridDB] Offline mode - using IndexedDB only', 'color: #f59e0b');
  }

  // ==================== CRUD with Sync ====================
  async getAll<T>(store: string): Promise<T[]> {
    return this.idb.getAll(store);
  }

  async add(store: string, item: any) {
    await this.idb.put(store, item);
    
    if (this.isOnline && isFirebaseEnabled) {
      await this.syncToFirebase(store, item);
    } else {
      this.syncQueue.push({ action: 'add', store, item });
    }
  }

  async update(store: string, item: any) {
    await this.idb.put(store, item);
    
    if (this.isOnline && isFirebaseEnabled) {
      await this.syncToFirebase(store, item);
    } else {
      this.syncQueue.push({ action: 'update', store, item });
    }
  }

  async delete(store: string, id: string) {
    await this.idb.delete(store, id);
    
    if (this.isOnline && isFirebaseEnabled) {
      await this.deleteFromFirebase(store, id);
    } else {
      this.syncQueue.push({ action: 'delete', store, id });
    }
  }

  // ==================== Firebase Sync ====================
  private async syncToFirebase(store: string, item: any) {
    if (!firestore) return;
    try {
      await setDoc(doc(collection(firestore, store), item.id), {
        ...item,
        syncedAt: Timestamp.now()
      });
    } catch (e) {
      console.error('[HybridDB] Firebase sync failed:', e);
    }
  }

  private async deleteFromFirebase(store: string, id: string) {
    if (!firestore) return;
    try {
      await deleteDoc(doc(collection(firestore, store), id));
    } catch (e) {
      console.error('[HybridDB] Firebase delete failed:', e);
    }
  }

  private async startSync() {
    if (!firestore) return;

    // Process queued changes
    while (this.syncQueue.length > 0) {
      const task = this.syncQueue.shift();
      if (task.action === 'add' || task.action === 'update') {
        await this.syncToFirebase(task.store, task.item);
      } else if (task.action === 'delete') {
        await this.deleteFromFirebase(task.store, task.id);
      }
    }

    // Pull latest from Firebase
    const stores = ['customers', 'contracts', 'invoices', 'employees'];
    for (const store of stores) {
      try {
        const snapshot = await getDocs(collection(firestore, store));
        snapshot.forEach(async (docSnap) => {
          const data = docSnap.data();
          await this.idb.put(store, data);
        });
      } catch (e) {
        console.warn(`[HybridDB] Failed to pull ${store}`);
      }
    }

    console.log('%c[HybridDB] Sync completed successfully', 'color: #22c55e');
  }

  // Force manual sync
  async forceSync() {
    if (this.isOnline && isFirebaseEnabled) {
      await this.startSync();
    } else {
      alert('لا يوجد اتصال بالإنترنت');
    }
  }
}

export const hybridDB = new HybridDB();